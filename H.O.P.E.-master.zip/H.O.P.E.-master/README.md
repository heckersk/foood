# H.O.P.E.
Help other people eat
 
